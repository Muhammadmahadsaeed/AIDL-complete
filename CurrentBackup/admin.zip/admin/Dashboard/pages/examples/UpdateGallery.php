<?php 
require_once('../../config/db.php');
require_once('./function.php'); 



if (isset($_GET['update'])) {
    $id = $_GET['update'];
    $sql = "select * from photos where photo_id=" .$id;
    $result = mysqli_query($link, $sql);
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
       
    } else {
        $errorMsg = 'Could not Find Any Record';
    }
}





if (isset($_POST['submit'])) { 
    $upload_dir = 'galleryImages/'; 
    
    $tittle = $_POST['imageName'];
    $image = $_FILES['image']['name'];
    
    
   
    if(empty($image)){
        $delImage = $row['tittle'].'_'.$row['images'];
        unlink($upload_dir.$delImage);
        
        $image = $tittle.'_'.$row['images'];
         // Location
    $location = "galleryImages/".basename($image);
    
    move_uploaded_file($_FILES['image']['tmp_name'], $location);
    $pImage = $row['images'];
       $update = "update photos set tittle  = '" . $tittle . "',images= '" . $pImage . "'  where photo_id=" . $id;
        // execute query
        if (mysqli_query($link, $update)){
          
          header('Location: ./gallery.php');
          exit();
        } 
        else {
          $msg = "Failed to upload image";
        }
   

    }
    else{
       
   
     
    $photo = $row['tittle'].'_'.$row['images'];
    unlink($upload_dir.$photo);
    

    $updateImage = $tittle.'_'.$image;
    // Location
    $location = "galleryImages/".basename($updateImage);
    
    move_uploaded_file($_FILES['image']['tmp_name'], $location);
    $update = "update photos set tittle  = '" . $tittle . "',images= '" . $image . "'  where photo_id=" . $id;
    // execute query
    if (mysqli_query($link, $update)){
     
      header('Location: ./gallery.php');
      exit();
    } 
    else {
      $msg = "Failed to upload image";
    }
    

    
 
    }
}



?>
<!DOCTYPE html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>AIDL</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
   
    <link rel="stylesheet" href="./style.css">
    <script>
      if(window.history.replaceState){
        window.history.replaceState(null,null,window.location.href)
      }
    </script>
</head>

<body class="hold-transition sidebar-mini">
    <!-- Site wrapper -->
    <div class="wrapper">
        <!-- Navbar -->
        <?php include("navbar.php")?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php require("../../sidebar.php")?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Add Photos</h1>
                        </div>
                        
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Gallery</h3>

                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                                        <i class="fas fa-minus"></i></button>
                                </div>
                            </div>
                            <form action=" "  method="post" enctype="multipart/form-data">
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="inputName">Image Name</label>
                                        <input type="text" id="inputName" name="imageName" value="<?= $row['tittle']?>" class="form-control">
                                    </div>
                                   <img src="./galleryImages/<?=$row['tittle']?>_<?=$row['images']?>" height="100px" width="100px" />
                                    <div class="form-group">
                                        <label for="inputDescription">Choose Image</label>
                                        <label for="fileUpload" class="file-upload btn btn-primary btn-block rounded-pill shadow">
                                            <i class="fa fa-upload mr-2"></i>
                                            Browse for file ...
                                            <input id="fileUpload" type="file" name="image">
                                        </label>
                                        
                                    </div>
                                    
                                    <div class="form-group">
                                        <a href="./gallery.php" class="btn btn-secondary">Cancel</a>
                                        <input type="submit" value="Update Photo" name="submit"  class="btn btn-success float-right">
                                    </div>
                                    <div id="images_list"></div>
                                </div>
                            </form>
                                <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>

                </div>

            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->



        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="../../plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../../dist/js/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../../dist/js/demo.js"></script>
</body>

</html>

