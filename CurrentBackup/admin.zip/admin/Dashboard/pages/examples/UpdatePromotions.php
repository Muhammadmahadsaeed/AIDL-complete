<?php require_once('../../config/db.php');
require_once('./function.php');

$upload_dir = './promotionsImages/';

if (isset($_GET['update'])) {
    $id = $_GET['update'];
    $sql = "select * from promotions where pro_id=" . $id;
    $result = mysqli_query($link, $sql);
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
    } else {
        $errorMsg = 'Could not Find Any Record';
    }
}

?>
<!DOCTYPE html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>AIDL</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
    <!-- Google Font: Source Sans Pro -->
    <!--<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">-->
    <link rel="stylesheet" href="./style.css">
    <script>
      if(window.history.replaceState){
        window.history.replaceState(null,null,window.location.href)
      }
    </script>
</head>

<body class="hold-transition sidebar-mini">
    <!-- Site wrapper -->
    <div class="wrapper">
        <!-- Navbar -->
        <?php include("navbar.php")?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php require("../../sidebar.php")?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Add Photos</h1>
                        </div>
                        
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Promotions</h3>

                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse"
                                        data-toggle="tooltip" title="Collapse">
                                        <i class="fas fa-minus"></i></button>
                                </div>
                            </div>
                            <form action="" id="upload_multiple_images" method="post" enctype="multipart/form-data">
                                <div class="card-body">
                                    
                                  
                                     <?php if($row['pro_type'] == 'wabinars' || $row['pro_type'] == 'video'){?>
                                     <div class="form-group"  id="videoField">
                                        <label for="video">Video URL</label>
                                        <input type="text" id="video" name="videoURL" value="<?= $row['video_url']?>" class="form-control">

                                    </div>
                                     <?php } ?>
                                    <div class="form-group"  id="imgCategory">
                                        <label for="inputName">Image Category</label>
                                        <input type="text" id="inputName" name="tittle" value="<?= $row['tittle']?>" class="form-control">

                                    </div>
                                    <img src="./promotionsImages/<?=$row['images']?>" height="100px" width="100px" />
                                    <div class="form-group"  id="imgButton">
                                        <label for="inputDescription">Choose Image</label>
                                        <label for="fileUpload"
                                            class="file-upload btn btn-primary btn-block rounded-pill shadow"><i
                                                class="fa fa-upload mr-2"></i>Browse for file ...
                                            <input id="fileUpload" type="file" multiple="multiple" name="image">
                                        </label>

                                    </div>
                                    <div class="form-group">
                                       
                                        <input type="submit" value="Update Promotions" name="updatePromotions" id="insert" class="btn btn-success float-right">
                                    </div>
                                    
                                </div>
                                <!-- /.card-body -->
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>

                </div>

            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->



        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="../../plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../../dist/js/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../../dist/js/demo.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</body>

</html>


<?php 
if(isset($_POST['updatePromotions'])){

   
    $video = $_POST['videoURL'];
    
    if($row['pro_type'] == 'video'){
        $insertvideo = "update promotions set pro_type ='".$row['pro_type']."',video_url ='".$video."' where pro_id=" .$id;
        if(mysqli_query($link,$insertvideo)){
          header('Location: ../promotions.php');
          exit();
            
        }else{
          echo $link->error;
            $statusMsg = "Sorry, there was an error uploading your file.";
        }
    }
    else{
        
    $filename = $_FILES['image']['name'];
    if(empty($filename)){
        $img = $row['images'];
         $sql = "update promotions set pro_type ='".$row['pro_type']."',video_url ='".$video."',tittle ='".strtolower($_POST['tittle'])."',images ='".$img."' where pro_id=" .$id;
         // execute query
         mysqli_query($link, $sql);
          header('Location: ../promotions.php');
          exit();
    } 
    else{
    unlink($upload_dir.$row['images']);
       // Valid extension
    $valid_ext = array('png','jpeg','jpg');

         
    $photoExt1 = @end(explode('.', $filename)); // explode the image name to get the extension
    $phototest1 = strtolower($photoExt1);
         
    $new_profle_pic = time().'.'.$phototest1;
         
    // Location
    $location = "./promotionsImages/".$new_profle_pic;

    // file extension
    $file_extension = pathinfo($location, PATHINFO_EXTENSION);
    $file_extension = strtolower($file_extension);

    // Check extension
    if(in_array($file_extension,$valid_ext)){  

         // Compress Image
         compressedImage($_FILES['image']['tmp_name'],$location,15);
             
         //Here i am enter the insert code in the step ........
         $sql = "update promotions set pro_type ='".$row['pro_type']."',video_url ='".$video."',tittle ='".strtolower($_POST['tittle'])."',images ='".$new_profle_pic."' where pro_id=" .$id;
         // execute query
         mysqli_query($link, $sql);
        header('Location: ../promotions.php');
          exit();
        
     }
     else{
             echo "File format is not correct.";
     } 
    }
    
 

    }

  
 
}
function compressedImage($source, $path, $quality) {

    $info = getimagesize($source);

    if ($info['mime'] == 'image/jpeg') 
        $image = imagecreatefromjpeg($source);

    elseif ($info['mime'] == 'image/gif') 
        $image = imagecreatefromgif($source);

    elseif ($info['mime'] == 'image/png') 
        $image = imagecreatefrompng($source);

    imagejpeg($image, $path, $quality);

}

?>