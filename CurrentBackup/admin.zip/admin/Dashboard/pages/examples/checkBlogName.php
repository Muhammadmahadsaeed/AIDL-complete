 <?php
    require_once('../../config/db.php');
    require_once('./function.php');
    if(isset($_GET['filter'])){
        
        $filter = trim($_GET['filter']);
       
        if(!empty($_GET['filter'])){
             $stmnt = $link->prepare("select blog_id,blog_name from blog where blog_name =?");
             $stmnt->bind_param('s',$filter);
       
            $stmnt->execute();
            $stmnt->store_result();
            $stmnt->bind_result($blog_id,$blog_name);
            $final = array();
            while($stmnt->fetch()){
                $each = array(
                    'blog_id'=>$blog_id,
                    'blog_name'=>$blog_name,
                    
                );
                array_push($final,$each);
            };
       
    echo json_encode($final);
}
}
?>