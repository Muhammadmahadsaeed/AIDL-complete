<?php require_once('../../config/db.php');
require_once('./function.php');

?>
<!DOCTYPE html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>AIDL</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
    <!-- Google Font: Source Sans Pro -->
    <!--<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">-->
    <link rel="stylesheet" href="./style.css">
    <script>
      if(window.history.replaceState){
        window.history.replaceState(null,null,window.location.href)
      }
    </script>
</head>

<body class="hold-transition sidebar-mini">
    <!-- Site wrapper -->
    <div class="wrapper">
        <!-- Navbar -->
        <?php include("navbar.php")?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php require("../../sidebar.php")?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Add Promotions</h1>
                        </div>
                        
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Promotions</h3>

                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse"
                                        data-toggle="tooltip" title="Collapse">
                                        <i class="fas fa-minus"></i></button>
                                </div>
                            </div>
                            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"
                                id="upload_multiple_images" method="post" enctype="multipart/form-data">
                                <div class="card-body">
                                    
                                    <div class="form-group">
                                    <label for="inputName">Choose Type</label><br>
                                        <select name="pro_type" class="form-control"  onchange="getComboA(this)">
                                            <option value="types">Choose Type</option>
                                            <option value="image">IMAGE</option>
                                            <option value="wabinars">WABINARS</option>
                                            <option value="video">VIDEO</option>
                                            <option value="promotions">PROMOTIONS</option>
                                        </select>
                                    </div>
                                       
                                     <div class="form-group" style="display:none" id="videoField">
                                        <label for="video">Video URL</label>
                                        <input type="text" id="video" name="videoURL" class="form-control">

                                    </div>
                                    <div class="form-group" style="display:none" id="imgCategory">
                                        <label for="inputName">Image Category</label>
                                        <input type="text" id="inputName" name="tittle" class="form-control">

                                    </div>
                                   
                                    <div class="form-group" style="display:none" id="imgButton">
                                        <label for="inputDescription">Choose Image</label>
                                        <label for="fileUpload"
                                            class="file-upload btn btn-primary btn-block rounded-pill shadow"><i
                                                class="fa fa-upload mr-2"></i>Browse for file ...
                                            <input id="fileUpload" type="file" multiple="multiple" name="image">
                                        </label>

                                    </div>
                                    <div class="form-group">
                                       
                                        <input type="submit" value="Add Promotions" name="submit" id="insert"
                                            class="btn btn-success float-right">
                                    </div>
                                    
                                </div>
                                <!-- /.card-body -->
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>

                </div>

            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->



        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="../../plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../../dist/js/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../../dist/js/demo.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</body>

</html>

<script>
function getComboA(selectObject) {
    var value = selectObject.value;
    
   if(value == "video"){
        document.getElementById('videoField').style.display = 'block'
        document.getElementById('imgCategory').style.display = 'none'
        document.getElementById('imgButton').style.display = 'none'
        
    }
    else if(value == 'wabinars'){
        document.getElementById('imgCategory').style.display = 'block'
        document.getElementById('imgButton').style.display = 'block'
        document.getElementById('videoField').style.display = 'block'
    }
    else if(value == 'image' || value == 'promotions'){
        document.getElementById('videoField').style.display = 'none'
        document.getElementById('imgCategory').style.display = 'block'
        document.getElementById('imgButton').style.display = 'block'
    }
    else{
        document.getElementById('videoField').style.display = 'none'
        document.getElementById('imgCategory').style.display = 'none'
        document.getElementById('imgButton').style.display = 'none'
    }
}
</script>

<?php 
if(isset($_POST['submit'])){

    $pro_type = $_POST['pro_type'];
    $video = $_POST['videoURL'];
    if($pro_type == "types"){
        echo '<script>swal("Bad job!", "Your Submission is going Wrong!", "error");</script>';
    }
    else if($pro_type == "video"){
        $insertvideo = "INSERT INTO promotions (pro_type,video_url) VALUES ('$pro_type','$video')";
        if(mysqli_query($link,$insertvideo)){
          echo '<script>swal("Good job!", "Your Submission is going Wrong!", "success");</script>';
            
        }else{
          echo $link->error;
            $statusMsg = "Sorry, there was an error uploading your file.";
        }
    }
    else{
        
    $filename = $_FILES['image']['name'];
         
    // Valid extension
    $valid_ext = array('png','jpeg','jpg');

         
    $photoExt1 = @end(explode('.', $filename)); // explode the image name to get the extension
    $phototest1 = strtolower($photoExt1);
         
    $new_profle_pic = time().'.'.$phototest1;
         
    // Location
    $location = "./promotionsImages/".$new_profle_pic;

    // file extension
    $file_extension = pathinfo($location, PATHINFO_EXTENSION);
    $file_extension = strtolower($file_extension);

    // Check extension
    if(in_array($file_extension,$valid_ext)){  

         // Compress Image
         compressedImage($_FILES['image']['tmp_name'],$location,15);
             
         //Here i am enter the insert code in the step ........
         $sql = "INSERT INTO promotions (pro_type,video_url,tittle,images) VALUES ('".$pro_type."','".$video."','".strtolower($_POST['tittle'])."','".$new_profle_pic."')";
         // execute query
         mysqli_query($link, $sql);
       
        
     }
     else{
             echo "File format is not correct.";
     }
 

 // Compress image



        


    }

  
 
}
function compressedImage($source, $path, $quality) {

    $info = getimagesize($source);

    if ($info['mime'] == 'image/jpeg') 
        $image = imagecreatefromjpeg($source);

    elseif ($info['mime'] == 'image/gif') 
        $image = imagecreatefromgif($source);

    elseif ($info['mime'] == 'image/png') 
        $image = imagecreatefrompng($source);

    imagejpeg($image, $path, $quality);

}

?>