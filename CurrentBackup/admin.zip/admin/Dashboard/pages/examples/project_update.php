<?php 

require_once('../../config/db.php');
require_once('./function.php');
$upload_dir = 'images/';
error_reporting(0);
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "select * from add_product where p_id=" . $id;
    $result = mysqli_query($link, $sql);
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
    } else {
        $errorMsg = 'Could not Find Any Record';
    }
}
if (isset($_POST['submit'])) { 
  $p_name = $_POST["name"];
  $p_des = $_POST["email"];
  $image = $_FILES['image']['name'];
  $c1 = $_POST["py"];
  $c2 = $_POST["ecmmm"];
  $c3 = $_POST["es"];
  $c4 = $_POST["ta"];
  $c5 = $_POST["nt"];
  
    if(empty($c1)&&empty($c2)&&empty($c3)&&empty($c4)&&empty($c5)){
      $cat_err="Please select atleast one category";
    }
    else{
    if(!empty($c1))
    {
      $c1=1;
    }
    else
    {
      $c1=0;
    }
    if(!empty($c2))
    {
      $c2=1;
    }
    else
    {
      $c2=0;
    }
    if(!empty($c3))
    {
      $c3=1;
    }
    else
    {
      $c3=0;
    }
    if(!empty($c4))
    {
      $c4=1;
    }
    else
    {
      $c4=0;
    }
    if(!empty($c5))
    {
      $c5=1;
    }
    else
    {
      $c5=0;
    }
  }
    
    if(empty($p_name)){
        $name_err = "Please enter product name";
    } elseif(!preg_match("/^[a-zA-Z ]*$/",$p_name)){
        $name_err = "Please enter a valid product name";
    } else{
       $p_name=$p_name;
    }
  
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }
    if(empty($p_des)){
        $des_err = "Please enter product description";     
    }else if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$p_des)) {
      $des_err = "Invalid URL";
    }
    
    else{
        $p_des = $p_des;
    }
    if((empty($image)) && (empty($row["p_img"]))){
      $img_err = "Please insert image";     
  } else if((empty($image)) && (!empty($row["p_img"]))){
      $image = $row["p_img"];
  }
  else
  {
    $image = $image;

  }
  if(empty($name_err) && empty($des_err) && empty($img_err)){
      unlink($upload_dir.$row['p_img']);   
    // Valid extension
    $valid_ext = array('png','jpeg','jpg');

         
    $photoExt1 = @end(explode('.', $image)); // explode the image name to get the extension
    $phototest1 = strtolower($photoExt1);
         
    $new_profle_pic = time().'.'.$phototest1;
         
    // Location
    $location = "./images/".$new_profle_pic;

    // file extension
    $file_extension = pathinfo($location, PATHINFO_EXTENSION);
    $file_extension = strtolower($file_extension);

    // Check extension
    if(in_array($file_extension,$valid_ext)){  

         // Compress Image
         compressedImage($_FILES['image']['tmp_name'],$location,60);
             
         //Here i am enter the insert code in the step ........
        $sql= "update add_product set p_name = '" . $p_name . "', p_url = '" . $p_des . "',cat_1 = '" . $c1 . "',cat_2 = '" . $c2 . "',cat_3 = '" . $c3 . "',cat_4 = '" . $c4 . "',cat_5 = '" . $c5 . "',p_img = '" . $new_profle_pic . "' where p_id=" . $id;
        
         // execute query
         mysqli_query($link, $sql);
         if($result){

            header('Location: ./projects.php');
            exit();
            }else{
            $errorMsg = 'Error '.mysqli_error($link);
            }
       
        
     }
     else{
             echo "File format is not correct.";
     }

        
    }
     

   
}

function compressedImage($source, $path, $quality) {

    $info = getimagesize($source);

    if ($info['mime'] == 'image/jpeg') 
        $image = imagecreatefromjpeg($source);

    elseif ($info['mime'] == 'image/gif') 
        $image = imagecreatefromgif($source);

    elseif ($info['mime'] == 'image/png') 
        $image = imagecreatefrompng($source);

    imagejpeg($image, $path, $quality);

}
    // Close connection
    mysqli_close($link);


?>
<!DOCTYPE html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AIDL</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <!--<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">-->

  <link rel="stylesheet" href="./style.css">
</head>

<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
    <!-- Navbar -->
    <?php include("navbar.php") ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php require("../../sidebar.php") ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Edit Product</h1>
            </div>
           
          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
        <form action="" method="post" enctype="multipart/form-data">
          <div class="row">
            <div class="col-md-6">
              <div class="card card-primary">
                <div class="card-header">
                  <h3 class="card-title">Product</h3>

                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                      <i class="fas fa-minus"></i></button>
                  </div>
                </div>
                <div class="card-body">

                  <div class="form-group">
                    <label for="inputName">Product Name</label>
                    <input type="text" name="name" id="inputName" class="form-control" value="<?= $row['p_name']; ?>">
                    <span class="help-block" style="color: red;"><?php echo $name_err;?></span>
                  </div>
                  <div class="form-group">
                    <label for="inputDescription">Product Webiste URL</label>
                    <input id="inputDescription" name="email" class="form-control" value="<?= $row['p_url']; ?>">
                    <span class="help-block" style="color: red;"><?php echo $des_err;?></span>
              
                  </div>
                  <div class="form-group">
                    <label for="sel1">Product Category</label><br>
                    <span class="help-block" style="color: red;"><?php echo $cat_err;?></span><br>
                   
                    <?php
                    if($row['cat_1'])
                    {?>
                        <input type="checkbox" name="py" value="py" checked="checked"><label>PHYSICS</label><br>  
                   <?php }
                   else{
                    ?>
                    <input type="checkbox" name="py" value="py"><label>PHYSICS</label><br>  
                   <?php } 
                    if($row['cat_2'])
                    {?>
                        <input type="checkbox" name="ecmmm" value="ecmmm" checked="checked"><label>Engineering Civil Mech.Materials. Metallurgy</label><br>
                   <?php }
                   else{
                    ?>
                     <input type="checkbox" name="ecmmm" value="ecmmm" ><label>Engineering Civil Mech.Materials. Metallurgy</label><br> 
                   <?php } 
                    if($row['cat_3'])
                    {?>
                        <input type="checkbox" name="es" value="es" checked="checked"><label>Earth Sciences</label><br>  
                   <?php }
                   else{
                    ?>
                   <input type="checkbox" name="es" value="es"><label>Earth Sciences</label><br>  
                   <?php } 
                   
                   if($row['cat_4'])
                    {?>
                        <input type="checkbox" name="ta" value="ta" checked="checked"><label>Teaching Aids</label><br>
                   <?php }
                   else{
                    ?>
                   <input type="checkbox" name="ta" value="ta"><label>Teaching Aids</label><br>  
                   <?php } 
                   if($row['cat_5'])
                    {?>
                         <input type="checkbox" name="nt" value="nt" checked="checked"><label>Nano Technology</label><br>  
                   <?php }
                   else{
                    ?>
                    <input type="checkbox" name="nt" value="nt"><label>Nano Technology</label><br>  
                   <?php } ?>

                   
                    
                  </div>

                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
            </div>
            <div class="col-md-6">
              <div class="card card-secondary">
                <div class="card-header">
                  <h3 class="card-title">Product Image</h3>

                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                      <i class="fas fa-minus"></i></button>
                  </div>
                </div>
                <div class="card-body">
                  <div class="form-group">
                    <label for="inputEstimatedBudget">Product Image</label>
                    
                    <img src="<?php echo $upload_dir . $row['p_img'] ?>" width="100"><br> <br>
                    <label for="inputEstimatedBudget" class="file-upload btn btn-primary btn-block rounded-pill shadow">
                      <i class="fa fa-upload mr-2"></i>
                      Browse for file ...
                       <input type="file" name="image" id="inputEstimatedBudget">
                    </label>
                    <span class="help-block" style="color: red;"><?php echo $img_err;?></span><br>
                   
                    
                  </div>
                  <div class="form-group">
                     <input type="submit" name="submit" value="Update product" class="btn btn-success float-right">
                     <a href='./projects.php' type="button" class="btn btn-primary float-left">Canel</a>
                  </div>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
            </div>

          </div>
         
        </form>
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->



    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="../../plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../../dist/js/adminlte.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../../dist/js/demo.js"></script>
</body>

</html>
