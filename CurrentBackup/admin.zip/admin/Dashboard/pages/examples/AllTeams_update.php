<?php   require_once('../../config/db.php');
require_once('./function.php');
$upload_dir = 'teamImages/';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "select * from team_members where team_id=" . $id;
    $result = mysqli_query($link, $sql);
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
       
    } else {
        $errorMsg = 'Could not Find Any Record';
    }
}





if (isset($_POST['update'])) { 
    $name = $_POST['name'];
    $Mempost = $_POST['Mempost'];
    $email = $_POST['email'];
    $num = $_POST['num'];
    $image = $_FILES['image']['name'];
    
    if(empty($image)){
    $image = $row['team_image'];
    
    $update = "update team_members set team_name  = '" . $name . "',team_post = '" . $Mempost . "',team_email = '" . $email . "',team_num = '" . $num . "',team_image= '" . $image . "'  where team_id=" . $id;
    // execute query
    if (mysqli_query($link, $update)){
      $msg = "Image uploaded successfully";
      header('Location: ./AllTeams.php');
      exit();
    } 
    else {
      $msg = "Failed to upload image";
    }
   

    }
    else{
    $upload_dir = './teamImages/';
    unlink($upload_dir.$row['team_image']);
    $valid_ext = array('jpeg','jpg');

         
    $photoExt1 = @end(explode('.', $image)); // explode the image name to get the extension
    $phototest1 = strtolower($photoExt1);
         
    $new_profle_pic = time().'.'.$phototest1;
         
    // Location
    $location = "teamImages/".$new_profle_pic;
     
    // file extension
    $file_extension = pathinfo($location, PATHINFO_EXTENSION);
    $file_extension = strtolower($file_extension);


    if(in_array($file_extension,$valid_ext)){  

    
    compressedImage($_FILES['image']['tmp_name'],$location,60);
    
    $update = "update team_members set team_name  = '" . $name . "',team_post = '" . $Mempost . "',team_email = '" . $email . "',team_num = '" . $num . "',team_image= '" . $new_profle_pic . "'  where team_id=" . $id;
    // execute query
    if (mysqli_query($link, $update)){
      $msg = "Image uploaded successfully";
      header('Location: ./AllTeams.php');
      exit();
    } 
    else {
      $msg = "Failed to upload image";
    }
    }  
    else{
        $er = "File format is not correct.";
     } 

    }
 
   
}
function compressedImage($source, $path, $quality) {

    $info = getimagesize($source);

    if ($info['mime'] == 'image/jpeg') 
        $image = imagecreatefromjpeg($source);

    elseif ($info['mime'] == 'image/gif') 
        $image = imagecreatefromgif($source);

    elseif ($info['mime'] == 'image/png') 
        $image = imagecreatefrompng($source);

    imagejpeg($image, $path, $quality);

}
?>
<!DOCTYPE html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>AIDL</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
    <!-- Google Font: Source Sans Pro -->
    <!--<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">-->

    <link rel="stylesheet" href="./style.css">
</head>

<body class="hold-transition sidebar-mini">
    <!-- Site wrapper -->
    <div class="wrapper">
        <!-- Navbar -->
        <?php include("navbar.php") ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php require("../../sidebar.php") ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Edit Team Members</h1>
                        </div>
                       
                    </div>
                </div>
                                        <!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <form class="" action="#" method="post" enctype="multipart/form-data">

                    <div class="row justify-content-center">

                        <div class="col-md-6">
                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">Edit Team Member Detail</h3>

                                    <div class="card-tools">
                                        <button type="button" class="btn btn-tool" data-card-widget="collapse"
                                            data-toggle="tooltip" title="Collapse">
                                            <i class="fas fa-minus"></i></button>
                                    </div>
                                </div>
                                <form class="" action="cadd.php" method="post" enctype="multipart/form-data">

                                    <div class="card-body">
                                        <div class="form-group">
                                            <label for="inputName">Team Member Name</label>
                                            <input type="text" id="inputName" name="name" value="<?= $row['team_name']?>" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="inputDescription">Post</label>
                                            <input type="text" id="inputDescription" name="Mempost" value="<?= $row['team_post']?>"
                                                class="form-control">
                                        </div>
                                        
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="text" id="email" name="email" value="<?= $row['team_email'];?>" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label for="num">Mobile Number</label>
                                        <input type="text" name="num" id="num" value="<?= $row['team_num']?>" class="form-control"  required>
                                     
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEstimatedBudget"
                                            class="file-upload btn btn-primary btn-block rounded-pill shadow"><i
                                                class="fa fa-upload mr-2"></i>Browse for file ...
                                            <input type="file" id="inputEstimatedBudget" name="image" value=<?= $row['team_image'];?>>
                                        </label>
                                        <span style="color:red"><?= $er ?></span>
                                        <!-- <label for="inputEstimatedBudget">Client Image</label>
                                        <input type="file" id="inputEstimatedBudget" name="image" class="form-control"> -->
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <!-- <a href="#" class="btn btn-secondary">Cancel</a> -->
                                            <input type="submit" name="update" value="Update Member"
                                                class="btn btn-success float-right">
                                        </div>
                                    </div>
                             

                                    </div>
                                    <!-- /.card-body -->
                            </div>
                            <!-- /.card -->
                        </div>
                     


                    </div>

                </form>
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->



        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="../../plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../../dist/js/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../../dist/js/demo.js"></script>
</body>

</html>


<?php 

$img = "";
if(isset($_POST['submit'])){

    $name = $_POST['name'];
    $Mempost = $_POST['Mempost'];
    $email = $_POST['email'];
    $num = $_POST['num'];
    $image = $_FILES['image']['name'];

    $target = "./teamImages/" . basename($image);

    $sql = "INSERT INTO team_members (team_name,team_post,team_email,team_num,team_image) VALUES ('$name','$Mempost','$email','$num','$image')";
    // execute query
    mysqli_query($link, $sql);
  
    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
      $msg = "Image uploaded successfully";
    } else {
      $msg = "Failed to upload image";
    }
}


?>