<?php 
require_once('../../config/db.php');
require_once('./function.php');


if(isset($_GET['id'])){
    $id = $_GET['id'];
    $sql = "select * from blog where blog_id=".$id;
    if ($result = mysqli_query($link, $sql)) {
        if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_array($result);
        }
    } 
    $sql2 = "select * from blog_images where blog_id =". $id;
    if($result = mysqli_query($link, $sql2)){
        if (mysqli_num_rows($result) > 0) {
        $row1 = mysqli_fetch_array($result);
        }
    }
}


?>

<!DOCTYPE html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>AIDL</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.ckeditor.com/4.13.0/standard/ckeditor.js"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
   <link rel="stylesheet" href="./style.css">
</head>

<body class="hold-transition sidebar-mini">
    <!-- Site wrapper -->
    <div class="wrapper">
        <!-- Navbar -->
        <?php include("navbar.php")?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php require("../../sidebar.php")?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Blog</h1>
                        </div>
                       
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">General</h3>

                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse"
                                        data-toggle="tooltip" title="Collapse">
                                        <i class="fas fa-minus"></i></button>
                                </div>
                            </div>

                            <div class="card-body">
                                <form action="" method="post" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label for="bName">Blog Name</label>
                                        <input type="text" id="bName" name="sname" value="<?=$row['blog_name']?>" class="form-control" value="">
                                        <span id="eor" style="color:red;display:none">Blog Name Already Exist</span>
                                    </div>
                                    <img src="./BlogImages/<?=$row1['blog_image']?>" height="100px" width="100px" />
                                    <div class="form-group">
                                        <label for="inputDescription">Blog Image</label>
                                        <label for="inputEstimatedBudget"
                                            class="file-upload btn btn-primary btn-block rounded-pill shadow"><i class="fa fa-upload mr-2"></i>
                                            Choose Single Image(JPG) ...
                                            <input type="file" id="inputEstimatedBudget" name="image">
                                        </label>
                                        
                                    </div>
                                    <div class="form-group">
                                        <label for="inputDescription">Blog Description</label>
                                        <textarea id="articleContent" name="articleContent" class="form-control"
                                            rows="4"><?=$row['blog']?> </textarea>

                                    </div>
                                    <div class="form-group">
                                    <input type="submit" name="submit" value="Update blog"
                                            class="btn btn-success float-right">
                                    </div>
                                </form>
                            </div>

                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>

                </div>

            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

</body>
<script>
CKEDITOR.replace('articleContent', {
    height: 300,
    filebrowserUploadUrl: "./UploadBlog.php",
    filebrowserUploadMethod: 'form'
});
</script>

<script src="../../ckeditor/ckeditor.js"></script>
<script src="../../ckeditor/config.js"></script>
<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>

<script>

  
</script>

</html>

<?php
if(isset($_POST['submit'])) { 
    
    $content  = $_POST['articleContent'];
  
    $name  = $_POST['sname'];
   
        $query = "update blog set blog_name = '".$name."', blog = '".$content."' where blog_id=".$id;
  
    if(mysqli_query($link, $query)){
        $selectBlogId = mysqli_query($link, "select blog_id from blog where blog_name = '".$name."' ");
        if(mysqli_num_rows($selectBlogId) > 0){
            $row = mysqli_fetch_assoc($selectBlogId);
           
        }
    $filename = $_FILES['image']['name'];
    if(empty($filename)){
        $new_profle_pic = $row1['blog_image'];
        $insert = mysqli_query($link,"update blog_images set blog_id = '".$row['blog_id']."',blog_name = '".$name."',blog_image = '".$new_profle_pic."' where blog_id=".$id);
        if($insert){
          header("Location: ./viewBlog.php");
            exit();
        }
        else{
          echo $link->error;
            $statusMsg = "Sorry, there was an error uploading your file.";
        }
    }
    else{
    $upload_dir = './BlogImages/';
    unlink($upload_dir.$row1['blog_image']);
     // Valid extension
    $valid_ext = array('png','jpeg','jpg');
         
    $photoExt1 = @end(explode('.', $filename)); // explode the image name to get the extension
    $phototest1 = strtolower($photoExt1);
         
    $new_profle_pic = time().'.'.$phototest1;
         
    // Location
    $location = "./BlogImages/".$new_profle_pic;

    // file extension
    $file_extension = pathinfo($location, PATHINFO_EXTENSION);
    $file_extension = strtolower($file_extension);

    // Check extension
    if(in_array($file_extension,$valid_ext)){  

         // Compress Image
        compressedImage($_FILES['image']['tmp_name'],$location,60);
             
        //Here i am enter the insert code in the step ........
        
            
        $insert = mysqli_query($link,"update blog_images set blog_id = '".$row['blog_id']."',blog_name = '".$name."',blog_image = '".$new_profle_pic."' where blog_id=".$id);
        if($insert){
          header("Location: ./viewBlog.php");
        exit();
        }
        else{
          echo $link->error;
            $statusMsg = "Sorry, there was an error uploading your file.";
        }
    }
    else{
        mysqli_error();
    }  
    }
    
       
        
    }
    else{
        echo "File format is not correct.";
    }
    
}   
   
    
function compressedImage($source, $path, $quality) {

    $info = getimagesize($source);

    if ($info['mime'] == 'image/jpeg') 
        $image = imagecreatefromjpeg($source);

    elseif ($info['mime'] == 'image/gif') 
        $image = imagecreatefromgif($source);

    elseif ($info['mime'] == 'image/png') 
        $image = imagecreatefrompng($source);

    imagejpeg($image, $path, $quality);

}

   
?>





