<?php 
require_once('../../config/db.php');

if (!isset($_SESSION['u_id'])) {
  header('location:../../../index.php?lmsg=true');
  
  exit;
}else{
    $idd=$_SESSION['u_id'];
}

?>