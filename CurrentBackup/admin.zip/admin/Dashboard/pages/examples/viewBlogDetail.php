<?php 
require_once('../../config/db.php');
if (isset($_GET['id'])) {
    $id = $_GET['id'];

$display = "select * from blog where blog_id = $id";
$res = mysqli_query($link,$display);
$displayImages = "select * from blog_images where blog_id = $id";
$resImages = mysqli_query($link,$displayImages);
 if (mysqli_num_rows($resImages) > 0) {
        $resultImages = mysqli_fetch_assoc($resImages);
       
    } else {
        $errorMsg = 'Could not Find Any Record';
    }

}
?>
<!DOCTYPE html>
<html>



<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    
    <title>AIDL - Associated Instruments Distributors (Pvt) Limited</title>
    <!-- Metadata -->
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="../../../../pages/assets/images/ico/favicon.png" />
    <!-- CSS Plugins -->
    <link rel="stylesheet" href="../../../../pages/assets/css/plugins.min.css">
    <!-- Custom CSS File -->
    <link rel="stylesheet" href="../../../../pages/assets/css/style.css">
</head>

<body>
    <div class="ms-main-container">
        <!-- Preloader -->
        <div class="ms-preloader"></div>
        <!-- Header -->
        <header class="ms-header">
            <nav class="ms-nav">
                <div class="ms-logo">
                    <a href="../../../../../" data-type="page-transition">
                        <div class="logo-dark current"><img src="../../../../pages/logo-light.svg" alt="logo image"></div>
                        <div class="logo-light"><img src="../../../../pages/logo-light.svg" alt="logo image"></div>
                    </a>
                </div>
                <button class="hamburger" type="button" data-toggle="navigation">
                    <span class="hamburger-box">
                        <span class="hamburger-label">menu</span>
                        <span class="hamburger-inner"></span>
                    </span>
                </button>
                <div class="height-full-viewport">
                    <ul class="ms-navbar">
                        <!-- Nav Link -->
                        <li class="nav-item">
                            <a href="../../../../../" data-type="page-transition">
                                <span class="ms-btn">home</span>

                            </a>
                        </li>
                        <!-- Nav Link -->
                        <!-- Nav Link -->
                        <li class="nav-item">
                            <a href="../../../../pages/about.php" data-type="page-transition">
                                <span class="ms-btn">about</span>

                            </a>

                        </li>
                        <!-- Nav Link -->
                        <li class="nav-item">
                            <a href="../../../../pages/ourTeams.php" data-type="page-transition">
                                <span class="ms-btn">our team</span>

                            </a>
                        </li>
                        <!-- Nav Link -->
                        <!-- Nav Link -->
                        <li class="nav-item">
                            <a href="../../../../pages/products.php" data-type="page-transition">
                                <span class="ms-btn">product</span>

                            </a>
                        </li>
                        <!-- Nav Link -->
                        <!-- Nav Link -->
                        <li class="nav-item">
                            <a href="../../../../pages/albums.php" data-type="page-transition">
                                <span class="ms-btn">gallery</span>

                            </a>
                        </li>
                        <!-- Nav Link -->
                        <li class="nav-item">
                            <a href="../../../../pages/contact.php" data-type="page-transition">
                                <span class="ms-btn">contact</span>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../../../../pages/ourClients.php" data-type="page-transition">
                                <span class="ms-btn">our clients</span>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../../../../pages/promotions.php" data-type="page-transition">
                                <span class="ms-btn">promotions</span>

                            </a>
                        </li>

                        <!-- Nav Link -->
                        <li class="nav-item">
                            <a href="../../../../pages/blog.php" data-type="page-transition">
                                <span class="ms-btn">blog</span>

                            </a>
                        </li>


                    </ul>
                </div>
            </nav>
        </header>
        <!-- Container -->
        <main class="ms-container">
            <!-- Page Title -->
            <div class="ms-section__block">
                <div class="ms-page-title">
                    <h2 class="page-header"><?=$resultImages['blog_name']?></h2>
                    <div class="post-item__date" style="padding-left: 12px;"><?=$resultImages['created_on']?></div>
                </div>
            </div>
            <!-- Page Content -->
            <div class="ms-section__block">
                
                <div id="ms-blog-post" class="row">
                    
                    <div class="col-md-8">
                       
                        <img src="./BlogImages/<?=$resultImages['blog_image']?>" alt="img"><br>
                      
                       
                       <div>
                           <?php while ($result = mysqli_fetch_array($res)) {
                             echo $result['blog'];
                            }?>
                       </div>
                        
                    </div>
                   
                </div>
            </div>
        </main>
        <!-- Footer -->
        
    </div>
    <!-- JS Libraries -->
    <!-- jquery-2.1.3.min js -->
    <script type="text/javascript" src='../../../../pages/assets/js/jquery-3.2.1.min.js'></script>
    <!-- Vendors -->
    <script type="text/javascript" src='../../../../pages/assets/js/plugins.min.js'></script>
    <!-- Main js -->
    <script type="text/javascript" src="../../../../pages/assets/js/main.js"></script>
</body>



</html>