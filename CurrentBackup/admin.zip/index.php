<?php require_once('./config.php'); ?>
<!DOCTYPE html>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>AIDL - Associated Instruments Distributors (Pvt) Limited</title>
    <!-- Metadata -->
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="./pages/assets/images/ico/favicon.ico" />
    <!-- CSS Plugins -->
    <link rel="stylesheet" href="./pages/assets/css/plugins.min.css">
    <!-- Custom CSS File -->
    <link rel="stylesheet" href="./pages/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <style>
    .mytest {
        color: white;
        position: absolute;
        bottom: 0px;
        width: 100%;
        z-index: 10000;
        left: 10;
        right: 10;
    }
    #customers {
        font-family: 'Century Gothic';
        border-collapse: collapse;
        width: 100%;
    }
    #customers td,
    #customers th {
        border: 1px solid #ddd;
        padding: 8px;
        color: black;
    }
    #customers tr:nth-child(even) {
        background-color: #f2f2f2;
    }
    #customers tr:hover {
        background-color: #ddd;
    }
    #customers th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: center;
        background-color: red;
        color: white;
    }
    .modal a.close-modal{
        background-image:url('./cross.png');
    }
    </style>
</head>
<body>
    <div class="ms-main-container">
        <!-- Preloader -->
        <div class="ms-preloader"></div>
        <!-- Header -->
        <header class="ms-header navbar-white">
            <nav class="ms-nav">
                <div class="ms-logo">
                    <a href="./" data-type="page-transition">
                        <div class="logo-dark"><img src="./pages/logo-light.svg" alt="logo image"></div>
                        <div class="logo-light current"><img src="./pages/logo-light.svg" alt="logo image"></div>
                    </a>
                </div>
                <button class="hamburger" type="button" data-toggle="navigation">
                    <span class="hamburger-box">
                        <span class="hamburger-label">menu</span>
                        <span class="hamburger-inner"></span>
                    </span>
                </button>
                <div class="height-full-viewport">
                    <ul class="ms-navbar">
                        <!-- Nav Link -->
                        <li class="nav-item">
                            <a href="./" data-type="page-transition">
                                <span class="ms-btn">home</span>
                            </a>
                        </li>
                        <!-- Nav Link -->
                        <!-- Nav Link -->
                        <li class="nav-item">
                            <a href="./pages/about.php" data-type="page-transition">
                                <span class="ms-btn">about us</span>
                            </a>
                        </li>
                        <!-- Nav Link -->
                        <li class="nav-item">
                            <a href="./pages/ourTeams.php" data-type="page-transition">
                                <span class="ms-btn">our Team</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="./pages/products.php" data-type="page-transition">
                                <span class="ms-btn">product</span>
                            </a>
                        </li>
                        <!-- Nav Link -->
                        <!-- Nav Link -->
                        <li class="nav-item">
                            <a href="./pages/albums.php" data-type="page-transition">
                                <span class="ms-btn">gallery</span>
                            </a>
                        </li>
                        <!-- Nav Link -->
                        <li class="nav-item">
                            <a href="./pages/contact.php" data-type="page-transition">
                                <span class="ms-btn">contact</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="./pages/ourClients.php" data-type="page-transition">
                                <span class="ms-btn">our clients</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="./pages/promotions.php" data-type="page-transition">
                                <span class="ms-btn">promotions</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="./pages/gallery.php" data-type="page-transition">
                                <span class="ms-btn">gallery</span>
                            </a>
                        </li>
                        <!-- Nav Link -->
                        <li class="nav-item">
                            <a href="./pages/blog.php" data-type="page-transition">
                                <span class="ms-btn">blog</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <!-- Container -->
        <main class="ms-container home-slider">
            <!-- Swiper Slider -->
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <!-- Slide -->
                    <div class="swiper-slide">
                        <div class="slide-inner" data-swiper-parallax="45%">
                            <div class="overlay"></div>
                            <div class="slide-inner--image"
                                style="background-image: url('./pages/assets/images/5.jpg')"></div>
                            <div class="slide-inner--info">
                                <h1>WELCOME TO<br>ASSOCIATED INSTRUMENT DISTRIBUTORS (PVT) LIMITED</h1>
                            </div>
                        </div>
                    </div>
                    <!-- Slide -->
                    <div class="swiper-slide">
                        <div class="slide-inner" data-swiper-parallax="45%">
                            <div class="overlay"></div>
                            <div class="slide-inner--image"
                                style="background-image: url('./pages/assets/images/1.jpg')">
                            </div>
                            <div class="slide-inner--info">
                                <h1> WE DELIVER <br>TECHNOLOGICALLY ADVANCED SOLUTIONS AND INSTRUMENT
                                    BRANDS</h1>
                            </div>
                        </div>
                    </div>
                    <!-- Slide -->
                    <div class="swiper-slide">
                        <div class="slide-inner" data-swiper-parallax="45%">
                            <div class="overlay"></div>
                            <div class="slide-inner--image"
                                style="background-image: url('./pages/assets/images/2.jpg')">
                            </div>
                            <div class="slide-inner--info">
                                <h1>WELCOME TO<br>ASSOCIATED INSTRUMENT DISTRIBUTORS (PVT) LIMITED</h1>
                            </div>
                        </div>
                    </div>
                    <!-- Slide -->
                    <div class="swiper-slide">
                        <div class="slide-inner" data-swiper-parallax="45%">
                            <div class="overlay"></div>
                            <div class="slide-inner--image"
                                style="background-image: url('./pages/assets/images/4.jpg')">
                            </div>
                            <div class="slide-inner--info">
                                <h1> WE DELIVER <br>TECHNOLOGICALLY ADVANCED SOLUTIONS AND INSTRUMENT
                                    BRANDS</h1>
                            </div>
                        </div>
                    </div>
                    <!-- Slide -->
                    <div class="swiper-slide">
                        <div class="slide-inner" data-swiper-parallax="45%">
                            <div class="overlay"></div>
                            <div class="slide-inner--image"
                                style="background-image: url('./pages/assets/images/3.jpg')">
                            </div>
                            <div class="slide-inner--info">
                                <h1>WELCOME TO<br>ASSOCIATED INSTRUMENT DISTRIBUTORS (PVT) LIMITED</h1>
                            </div>
                        </div>
                    </div>
                    <!-- Slide -->
                    <div class="swiper-slide">
                        <div class="slide-inner" data-swiper-parallax="45%">
                            <div class="overlay"></div>
                            <div class="slide-inner--image"
                                style="background-image: url('./pages/assets/images/4.jpg')">
                            </div>
                            <div class="slide-inner--info">
                                <h1> WE DELIVER <br>TECHNOLOGICALLY ADVANCED SOLUTIONS AND INSTRUMENT
                                    BRANDS</h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mytest">
                    <div class="contactBtn">
                        <a href="#contactUs"  style="color:white;padding: 0.5em;background-color: red;" rel="modal:open">
                             Contact Us
                        </a>
                    </div>
                   <?php $news = "select * from news";
                    $newsResult = mysqli_query($link, $news);
                    if(mysqli_num_rows($newsResult)){
                    
                                            
                    ?>
                   
                        <marquee behavior="" direction="left"> 
                        <?php 
                    while($row = mysqli_fetch_assoc($newsResult)){ 
                        if($row['flag'] == 'start'){
                            $myDate = date('F j, Y',strtotime($row["created_on"]));
                            $new='['.$myDate.']-';
                            echo '<small style="color:white">'.$new.'</small>'.$row["news"]; 
                     }}
                      ?>
                        </marquee>
                   <?php 
                    
                    } 
                ?>
                </div>
            </div>
        </main>
        <!-- /Container -->
        <div class="modal" id="contactUs">
           
                <!-- Modal content-->
            <div class="modal-content">
                    <div class="modal-header">
                        
                        <h4 style="color:black;text-align:center">Contact Us</h4>
                    </div>
                    <div class="modal-body" style="overflow-x:auto;">
                        <table id="customers">
                            <tr>
                                <th style="width:30%">Company</th>
                                <th>AIDL Pakistan</th>
                            </tr>
                            <tr>
                                <td>MANAGING DIRECTOR</td>
                                <td>HUSSAIN CEEN Tayyab</td>
                            </tr>
                            <tr>
                                <td>Contact No</td>
                                <td>+92-21-32735734 - 32767475-7 - 32729361</td>
                            </tr>
                            <tr>
                                <td>Email</td>
                                <td><a href="mailto:aidl@cyber.net.pk" target="_blank">aidl@cyber.net.pk</a> </td>
                            </tr>
                            <tr>
                                <td>Location</td>
                                <td>HEAD OFFICE: <br>
                                   <a href="https://www.google.com/maps/place/Rimpa+Plaza,+M.A+Jinnah+Rd,+Preedy+Quarters+Karachi,+Karachi+City,+Sindh,+Pakistan/@24.8644286,67.0207203,17z/data=!4m8!1m2!2m1!1s7-8,+5th+Floor+Office+Tower,+Rimpa+Plaza,+MA+Jinnah+Road!3m4!1s0x3eb33e6cb30efc85:0x7c1800b871868b7c!8m2!3d24.8644285!4d67.0229088" target="_blank"> 7-8, 5th Floor Office Tower,
                                    Rimpa Plaza, MA Jinnah Road</a></td>
                            </tr>
                        </table>
                    </div>
                    
                </div>
           
        </div>
    </div>
    <!-- JS Libraries -->
    <!-- jquery-2.1.3.min js -->
    <script type="text/javascript" src='./pages/assets/js/jquery-3.2.1.min.js'></script>
    <!-- Vendors -->
    <script type="text/javascript" src='./pages/assets/js/plugins.min.js'></script>
    <!-- Main js -->
    <script type="text/javascript" src="./pages/assets/js/main.js"></script>
    <!-- jQuery Modal -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
</body>
<script>
var swiper = new Swiper('.swiper-container', {
    spaceBetween: 30,
    centeredSlides: true,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
});

</script>
</html>